# Corbett Travel Hub Landing Page

## Free publishing
Upload this folder to a GitHub repository and enable GitHub Pages.

## Important
- Replace the placeholder package prices/content with your real offers before publishing.
- The WhatsApp and Call buttons are already linked to +91 95285 26785.
- `images/design-reference.png` is included as a visual reference from the generated mockup. For a production site, replace the CSS background/photo blocks with properly licensed Corbett/tiger photos you have rights to use.
